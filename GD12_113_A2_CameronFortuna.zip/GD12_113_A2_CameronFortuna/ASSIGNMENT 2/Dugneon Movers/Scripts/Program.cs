﻿using Dugneon_Movers.Scripts.dice_game;

namespace Dugneon_Movers.Scripts
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GameManager manager = new GameManager();
            manager.Intro();
        }
    }
}

