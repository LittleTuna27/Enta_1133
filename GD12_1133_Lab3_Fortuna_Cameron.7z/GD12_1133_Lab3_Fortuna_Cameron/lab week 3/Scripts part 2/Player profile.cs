﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_week_3.Scripts_part_2
{
    internal class Player_profile
    {
        public int playerScore = 0; //a intger to hold the player score
    }
}