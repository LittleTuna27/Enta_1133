﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_week_3.Scripts_part_2
{
    internal class Player_Vs_Computer
    {
        public int computerScore = 0; //a intger to hold the computerts score
    }
}
