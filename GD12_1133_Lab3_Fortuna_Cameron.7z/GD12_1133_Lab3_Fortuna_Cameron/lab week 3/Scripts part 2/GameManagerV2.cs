﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_week_3.Scripts_part_2
{
    internal class GameManagerV2  //this is creating the container to hold the code so you can call this script to other scripts
    {
        public int score = 0;

        Player_Vs_Computer computer = new Player_Vs_Computer();
        Player_profile player = new Player_profile();
        DiceRollerV2 sixSidedDice = new DiceRollerV2();

        DiceRollerV2 eightSidedDice = new DiceRollerV2();
        DiceRollerV2 twelveSidedDice = new DiceRollerV2();
        DiceRollerV2 twentySidedDice = new DiceRollerV2();

        bool WantToPlay = true;
        bool sixSidedDiceLeft = true;
        bool eightSidedDiceLeft = true;
        bool twelveSidedDiceLeft = true;
        bool twentySidedDiceLeft = true;

        string nameSave;
        public void SetUpDice()
        {
            eightSidedDice.totalSides = 8;
            twelveSidedDice.totalSides = 12;
            twentySidedDice.totalSides = 20;

            int randomD6Roll = sixSidedDice.RandomDiceRoll();
            int randomD8Roll = eightSidedDice.RandomDiceRoll();
            int randomD2Roll = twelveSidedDice.RandomDiceRoll();
            int randomD20Roll = twentySidedDice.RandomDiceRoll();

            Console.WriteLine($"Rolled a {sixSidedDice.totalSides} sidded die as result of {randomD6Roll}");
        }
        public void ProgramStart() //this is at the start execute these things in this order
        {
            Intro(); //introduction of me and the game
            GameLoop(); // main chunck of coding for the game
            MaybeNextTime();
            Outro(); //text of saying thanks

            score = score + sixSidedDice.RandomDiceRoll();


        }
       

        
        public void Intro() //the start of code for the intro
        {
            //if (WantToPlay())
                Console.WriteLine("Hello, World"); //just a simple greeting
                Console.WriteLine("I'm Cameron Fortuna in Enta 1133 GD12"); //just an intoduction of myself 
                Console.WriteLine("Who are you");
                nameSave = Console.ReadLine();

        }
        public void ChangeScore()// a function to change the score depending on the result of the dice roll
        {
            score += sixSidedDice.RandomDiceRoll(); // calling for my dice roller function to trigger to give me a random roll then adding it to my score
            Console.WriteLine("You rolled a " + sixSidedDice.previousResults); //calling the previous result of the random dice roll to display what they have rolled
        }

        public void DiceSelection()
        {

            string text = "d";
            int number = 6;

            Console.WriteLine("What dice do you want to roll");
            if (int.TryParse(Console.ReadLine(), out number))
            {
                DiceRollerV2 userSizeDice = new DiceRollerV2();
                userSizeDice.totalSides = number;
                //userSizeDice.RandomDiceRoll(IReadOnlyDictionary user.score);
             }
            else
            {
                Console.WriteLine("ERROR, Please eneter a valid answer!");
            }
        }

        public void GameLoop() //the start of the gameplay loop
        {
            Console.WriteLine("Welcome to Die vs Die!");
            ChangeScore(); //calling the function 4 times as that was how many times we wanted the dice to roll
            ChangeScore();
            ChangeScore();
            ChangeScore();
            Console.WriteLine("your total roll was " + score); //saying what their final score is at the score
        }

            public void DetermineStart()
            {
                print
            }
            public void MaybeNextTime()
             {

             }
        public void Outro() //a simple function to play a thank you for playing
        {
            Console.WriteLine("Thanks for playing my game");
            Console.WriteLine(nameSave);
            Console.WriteLine("Goodbye");

        }
    }
}