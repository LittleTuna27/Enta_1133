﻿using lab_week_3.Scripts_part_2;

namespace lab_week_3
{  
    internal class Program
    {
        static void Main(string[] args)
        {
            GameManagerV2 manager = new GameManagerV2();

             manager.ProgramStart();
        }
    }
}



